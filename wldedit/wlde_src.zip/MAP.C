#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wld.h"
#include "wldedit.h"
#include "map.h"

void MapClear(HWND hWnd) {
  int   x;
  int   y;
  HWND  hActive;
  char  buf[256];
  WLD * wld;

  /* clear map */
  for (y=0; y<BWLD_MAXROW; y++) {
    for(x=0; x<BWLD_MAXCOLUMN; x++) {
      hActive = hBWld[y*BWLD_MAXCOLUMN + x];
      GetWindowText(hActive, buf, sizeof(buf));
      if (*buf) {
        wld = WldFind(atol(buf));
        if (wld) wld->wHWnd = NULL;
      }
      SetWindowText(hActive, "");
      MapEnableExit(hWnd, hActive, x, y);
    }
  }
  MapSetActive(hWnd, NULL);
}

void MapSave(char *filename) {
  FILE    *file;
  long    x;
  long    y;
  long    i;
  char    buf[256];
  char    mapName[256];
  
  strcpy(mapName, filename);
  for(i=0; mapName[i] && mapName[i]!='.'; i++);
  if (mapName[i]=='.')
    strcpy(mapName+i, ".map");
  else
    strcat(mapName, ".map");
  file = fopen(mapName, "wb");
  for (y=0; y<BWLD_MAXROW; y++) {

    /* Write Rooms */
    for (x=0; x<BWLD_MAXCOLUMN; x++) {
      GetWindowText(hBWld[y*BWLD_MAXCOLUMN+x], buf, sizeof(buf));
      fprintf(file, "%s", buf);
      i = 6-strlen(buf); /* how many chars we have to fill */
      
      /* Write horizontal exit here */
      buf[0]=0;
      if (x<BWLD_MAXCOLUMN-1 && hBHorz[y*(BWLD_MAXCOLUMN-1)+x])
        GetWindowText(hBHorz[y*(BWLD_MAXCOLUMN-1)+x], buf, sizeof(buf));
      if (*buf)
        for(;i>0; i--) fprintf(file, "-");
      else
        for(;i>0; i--) fprintf(file, " ");
    }

    /* draw vertical exits */
    fprintf(file, "\n");
    for (x=0; x<BWLD_MAXCOLUMN; x++) {
      buf[0]=0;
      if (y<BWLD_MAXROW-1 && hBVert[y*BWLD_MAXCOLUMN+x])
        GetWindowText(hBVert[y*BWLD_MAXCOLUMN+x], buf, sizeof(buf));
      if (*buf)
        fprintf(file, "  |   ");
      else
        fprintf(file, "      ");
    }

    /* new line */
    fprintf(file, "\n");
  }
  
  /* Close up shop */
  fprintf(file, "$~\n#9999");
  fclose(file);
}

void MapOpen(HWND hWnd, char *filename) {
  FILE    *file;
  char    buf[256];
  char    mapName[256];
  char    word[256];
  int     x;
  int     y;
  int     i;
  int     exit = FALSE;
  WLD     *wld;
  
  MapClear(hWnd);
  
  strcpy(mapName, filename);
  for(i=0; mapName[i] && mapName[i]!='.'; i++);
  if (mapName[i]=='.')
    strcpy(mapName+i, ".map");
  else
    strcat(mapName, ".map");
  file = fopen(mapName, "r");
  if (!file) return;

  for (y=0; y<BWLD_MAXROW; y++) {
    /* scan rooms and horz exits */
    buf[0]=0;
    fgets(buf, sizeof(buf), file);
    for(x=0; x<BWLD_MAXCOLUMN; x++) {
      strncpy(word, buf + 6*x, 6); /* not interested in exits yet */
      word[6] = 0;
      for(i=0;word[i];i++) if (word[i]=='-') word[i]=' ';
      
      if (atol(word)>0)
        wld = WldFind(atol(word));
      else
        wld = NULL;
      if (wld) {
        hActive = hBWld[y*BWLD_MAXCOLUMN + x];
        sprintf(word, "%ld", wld->wVirtual);
        SetWindowText(hActive, word);
        wld->wHWnd = hActive;
        MapEnableExit(hWnd, hActive, x, y);
        MapSetExit(hWnd, wld, x, y);
      }
    } 

    /* scan vert exits */
    fgets(buf, sizeof(buf), file); 
  }
  
  fclose(file);
}


/* For placing rooms down that were created without a map */
void MapPlaceWld(HWND hWnd, WLD *wld, int x, int y) {
  HWND    hActive;
  char    buf[256];
  WLD     *exitWld;
  
  /* block if we go off the screen */
  if (x<0 || y<0 || x>=BWLD_MAXCOLUMN || y>=BWLD_MAXROW) return; 
  /* block if its on the screen allready somewhere else */
  if (wld->wHWnd) return; 

  hActive = hBWld[(y)*BWLD_MAXCOLUMN + (x)];
  sprintf(buf, "%ld", wld->wVirtual);
  SetWindowText(hActive, buf);
  wld->wHWnd = hActive;
  
  /* left */
  if (x>0) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN+(x-1)], buf, sizeof(buf));
    if (!*buf) {
      exitWld = WldFind(wld->wEDir[EDIR_WEST].eVirtual);
      if (exitWld && exitWld->wEDir[EDIR_EAST].eVirtual == wld->wVirtual) {
        MapPlaceWld(hWnd, exitWld, x-1, y);
      }
    }
  }
  
  /* right */
  if (x<BWLD_MAXCOLUMN-1) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN+(x+1)], buf, sizeof(buf));
    if (!*buf) {
      exitWld = WldFind(wld->wEDir[EDIR_EAST].eVirtual);
      if (exitWld && exitWld->wEDir[EDIR_WEST].eVirtual == wld->wVirtual) {
        MapPlaceWld(hWnd, exitWld, x+1, y);
      }
    }
  }
  
  /* up */
  if (y>0) {
    GetWindowText(hBWld[(y-1)*BWLD_MAXCOLUMN+x], buf, sizeof(buf));
    if (!*buf) {
      exitWld = WldFind(wld->wEDir[EDIR_NORTH].eVirtual);
      if (exitWld && exitWld->wEDir[EDIR_SOUTH].eVirtual == wld->wVirtual) {
        MapPlaceWld(hWnd, exitWld, x, y-1);
      }
    }
  }
  
  /* down */
  if (y<BWLD_MAXROW-1) {
    GetWindowText(hBWld[(y+1)*BWLD_MAXCOLUMN+x], buf, sizeof(buf));
    if (!*buf) {
      exitWld = WldFind(wld->wEDir[EDIR_SOUTH].eVirtual);
      if (exitWld && exitWld->wEDir[EDIR_NORTH].eVirtual == wld->wVirtual) {
        MapPlaceWld(hWnd, exitWld, x, y+1);
      }
    }
  }
  
  MapEnableExit(hWnd, hActive, x, y);
  MapSetExit(hWnd, wld, x, y);
}

/* Sets X's in the exits that are supposed to have exits */
void MapSetExit(HWND hWnd, WLD *wld, int x, int y) {
  WLD     *exitWld;
  HWND    hActive;
  char    word[256];

  if (!wld) return;
  hActive = hBWld[y*BWLD_MAXCOLUMN + x];
  /* set X in horizontal/left exit accordingly */
  if (x>0 && hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)]) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x - 1], word, sizeof(word));
    exitWld = WldFind(atol(word));
    if (exitWld
     && exitWld->wEDir[EDIR_EAST].eVirtual == wld->wVirtual
     && wld->wEDir[EDIR_WEST].eVirtual == exitWld->wVirtual) {
      SetWindowText(hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)], "X");
    } else {
      SetWindowText(hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)], "");
    }
  }
  
  /* set X in horizontal/right exit accordingly */
  if (x<BWLD_MAXCOLUMN-1 && hBHorz[y*(BWLD_MAXCOLUMN-1)+(x)]) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x + 1], word, sizeof(word));
    exitWld = WldFind(atol(word));
    if (exitWld
     && exitWld->wEDir[EDIR_WEST].eVirtual == wld->wVirtual
     && wld->wEDir[EDIR_EAST].eVirtual == exitWld->wVirtual) {
      SetWindowText(hBHorz[y*(BWLD_MAXCOLUMN-1)+(x)], "X");
    } else {
      SetWindowText(hBHorz[y*(BWLD_MAXCOLUMN-1)+(x)], "");
    }
  }
  
  /* set X in vertical/above exit accordingly */
  if (y>0 && hBVert[(y-1)*BWLD_MAXCOLUMN+x]) {
    GetWindowText(hBWld[(y-1)*BWLD_MAXCOLUMN + x], word, sizeof(word));
    exitWld = WldFind(atol(word));
    if (exitWld
     && exitWld->wEDir[EDIR_SOUTH].eVirtual == wld->wVirtual
     && wld->wEDir[EDIR_NORTH].eVirtual == exitWld->wVirtual) {
      SetWindowText(hBVert[(y-1)*BWLD_MAXCOLUMN+x], "X");
    } else {
      SetWindowText(hBVert[(y-1)*BWLD_MAXCOLUMN+x], "");
    }
  }

  /* set X in vertical/below exit accordingly */
  if (y<BWLD_MAXROW-1 && hBVert[(y)*BWLD_MAXCOLUMN+x]) {
    GetWindowText(hBWld[(y+1)*BWLD_MAXCOLUMN + x], word, sizeof(word));
    exitWld = WldFind(atol(word));
    if (exitWld
     && exitWld->wEDir[EDIR_NORTH].eVirtual == wld->wVirtual
     && wld->wEDir[EDIR_SOUTH].eVirtual == exitWld->wVirtual) {
      SetWindowText(hBVert[(y)*BWLD_MAXCOLUMN+x], "X");
    } else {
      SetWindowText(hBVert[(y)*BWLD_MAXCOLUMN+x], "");
    }
  }
}

/* Passing an hActive of NULL will disable surrounding exits by default, 
 other wise it will enable / disable based on hActive pointing
 to a full/empty map square on the grid */
void MapEnableExit(HWND hWnd, HWND hActive, int x, int y) {
  char buf[256];
  char center[256];

  /* 
   * enable/disable exits appropriately 
   */
  if (hActive) {
    /* confirm that there is data at the center */
    GetWindowText(hActive, center, sizeof(center));
  } else
    strcpy(center, ""); /* otherwise assume there is nothing in the center */
  
  /* Check exit to the left/west */
  if (x>=1) {
    GetWindowText(hBWld[(x-1)+y*BWLD_MAXCOLUMN], buf, sizeof(buf));
    if (*buf && *center) {
      if (!hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)]) {
        hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)] = CreateWindow("BUTTON", "",
          WS_CHILD|WS_VISIBLE,
          (x-1)*45+30, y*29, 15, 15,
          hWnd, IDC_BHORZ+y*(BWLD_MAXCOLUMN-1)+(x-1), hInst, NULL);
      }
    } else if (hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)]) {
      DestroyWindow(hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)]);
      hBHorz[y*(BWLD_MAXCOLUMN-1)+(x-1)] = NULL;
    }
  }
  /* Check exit to the right/east */
  if (x<(BWLD_MAXCOLUMN-1)) {
    GetWindowText(hBWld[(x+1)+y*BWLD_MAXCOLUMN], buf, sizeof(buf));
    if (*buf && *center) {
      if (!hBHorz[y*(BWLD_MAXCOLUMN-1)+x]) {
        hBHorz[y*(BWLD_MAXCOLUMN-1)+x] = CreateWindow("BUTTON", "",
          WS_CHILD|WS_VISIBLE,
          x*45+30, y*29, 15, 15,
          hWnd, IDC_BHORZ+y*(BWLD_MAXCOLUMN-1)+x, hInst, NULL);
      }
    } else if (hBHorz[y*(BWLD_MAXCOLUMN-1)+x]) {
      DestroyWindow(hBHorz[y*(BWLD_MAXCOLUMN-1)+x]);
      hBHorz[y*(BWLD_MAXCOLUMN-1)+x] = NULL;
    }
  }
  /* Check exit to the up/north */
  if (y>=1) {
    GetWindowText(hBWld[x+(y-1)*BWLD_MAXCOLUMN], buf, sizeof(buf));
    if (*buf && *center) {
      if (!hBVert[(y-1)*BWLD_MAXCOLUMN+x]) {
        hBVert[(y-1)*BWLD_MAXCOLUMN+x] = CreateWindow("BUTTON", "",
          WS_CHILD|WS_VISIBLE,
          x*45+7, (y-1)*29+15, 15, 15,
          hWnd, IDC_BVERT+(y-1)*BWLD_MAXCOLUMN+x, hInst, NULL); 
      }
    } else if (hBVert[(y-1)*BWLD_MAXCOLUMN+x]) {
      DestroyWindow(hBVert[(y-1)*BWLD_MAXCOLUMN+x]);
      hBVert[(y-1)*BWLD_MAXCOLUMN+x] = NULL;
    }
  }
  /* Check exit to the down/south */
  if (y<(BWLD_MAXROW-1)) {
    GetWindowText(hBWld[x+(y+1)*BWLD_MAXCOLUMN], buf, sizeof(buf));
    if (*buf && *center) {
      if (!hBVert[y*BWLD_MAXCOLUMN+x]) {
        hBVert[y*BWLD_MAXCOLUMN+x] = CreateWindow("BUTTON", "",
          WS_CHILD|WS_VISIBLE,
          x*45+7, y*29+15, 15, 15,
          hWnd, IDC_BVERT+y*BWLD_MAXCOLUMN+x, hInst, NULL); 
      }
    } else if (hBVert[y*BWLD_MAXCOLUMN+x]) {
      DestroyWindow(hBVert[y*BWLD_MAXCOLUMN+x]);
      hBVert[y*BWLD_MAXCOLUMN+x] = NULL;
    }
  }
} 

void MapShiftLeft(HWND hWnd) {
  int   x;
  int   y;
  char  buf[256];
  WLD * wld;

  /* Zero written over row */
  x=0;
  for(y=0; y<BWLD_MAXROW; y++) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      if (wld) wld->wHWnd = NULL;
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], "");
    }
  }
  
  /* Shift */
  for(y=0; y<BWLD_MAXROW; y++) {
    for(x=0; x<BWLD_MAXCOLUMN-1; x++) {
      GetWindowText(hBWld[(y)*BWLD_MAXCOLUMN + (x+1)], buf, sizeof(buf));
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
      if (*buf) {
        wld = WldFind(atol(buf));
        if (wld) wld->wHWnd = hBWld[y*BWLD_MAXCOLUMN + x];
      }
    }
  }
  
  /* Fill in new row */
  x=BWLD_MAXCOLUMN-1;
  for(y=0; y<BWLD_MAXROW; y++)
    SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
  x=BWLD_MAXCOLUMN-2;
  for(y=0; y<BWLD_MAXROW; y++) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      if (wld)
        MapPlaceWld(hWnd, wld, x, y);
    }
  }

  /* Correct Exits */
  for(y=0; y<BWLD_MAXROW; y++) {
    for(x=0; x<BWLD_MAXCOLUMN-1; x++) {
      MapEnableExit(hWnd, hBWld[y*BWLD_MAXCOLUMN + x], x, y);
      GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
      if (*buf) {
        wld = WldFind(atol(buf));
        MapSetExit(hWnd, wld, x, y);
      }
    }
  }
}

void MapShiftRight(HWND hWnd) {
  int   x;
  int   y;
  char  buf[256];
  WLD * wld;

  /* Zero written over row */
  x=BWLD_MAXCOLUMN-1;
  for(y=0; y<BWLD_MAXROW; y++) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      wld->wHWnd = NULL;
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], "");
    }
  }
  
  /* Shift */
  for(y=0; y<BWLD_MAXROW; y++) {
    for(x=BWLD_MAXCOLUMN-1; x>0; x--) {
      GetWindowText(hBWld[(y)*BWLD_MAXCOLUMN + (x-1)], buf, sizeof(buf));
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
      if (*buf) {
        wld = WldFind(atol(buf));
        wld->wHWnd = hBWld[y*BWLD_MAXCOLUMN + x];
      }
    }
  }
  
  /* Fill in new row */
  x=0;
  for(y=0; y<BWLD_MAXROW; y++)
    SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
  x=1;
  for(y=0; y<BWLD_MAXROW; y++) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      if (wld)
        MapPlaceWld(hWnd, wld, x, y);
    }
  }

  /* Correct Exits */
  for(y=0; y<BWLD_MAXROW; y++) {
    for(x=0; x<BWLD_MAXCOLUMN-1; x++) {
      MapEnableExit(hWnd, hBWld[y*BWLD_MAXCOLUMN + x], x, y);
      GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
      if (*buf) {
        wld = WldFind(atol(buf));
        MapSetExit(hWnd, wld, x, y);
      }
    }
  }
}

void MapShiftUp(HWND hWnd) {
  int   x;
  int   y;
  char  buf[256];
  WLD * wld;

  /* Zero written over row */
  y=0;
  for(x=0; x<BWLD_MAXCOLUMN; x++) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      wld->wHWnd = NULL;
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], "");
    }
  }
  
  /* Shift */
  for(y=0; y<BWLD_MAXROW-1; y++) {
    for(x=0; x<BWLD_MAXCOLUMN; x++) {
      GetWindowText(hBWld[(y+1)*BWLD_MAXCOLUMN + (x)], buf, sizeof(buf));
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
      if (*buf) {
        wld = WldFind(atol(buf));
        wld->wHWnd = hBWld[y*BWLD_MAXCOLUMN + x];
      }
    }
  }
  
  /* Fill in new row */
  y=BWLD_MAXROW-1;
  for(x=0; x<BWLD_MAXCOLUMN; x++)
    SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
  y=BWLD_MAXROW-2;
  for(x=0; x<BWLD_MAXCOLUMN; x++){
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      if (wld)
        MapPlaceWld(hWnd, wld, x, y);
    }
  }

  /* Correct Exits */
  for(y=0; y<BWLD_MAXROW; y++) {
    for(x=0; x<BWLD_MAXCOLUMN-1; x++) {
      MapEnableExit(hWnd, hBWld[y*BWLD_MAXCOLUMN + x], x, y);
      GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
      if (*buf) {
        wld = WldFind(atol(buf));
        MapSetExit(hWnd, wld, x, y);
      }
    }
  }
}

void MapShiftDown(HWND hWnd) {
  int   x;
  int   y;
  char  buf[256];
  WLD * wld;

  /* Zero written over row */
  y=BWLD_MAXROW-1;
  for(x=0; x<BWLD_MAXCOLUMN; x++) {
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      wld->wHWnd = NULL;
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], "");
    }
  }
  
  /* Shift */
  for(y=BWLD_MAXROW-1; y>0; y--) {
    for(x=0; x<BWLD_MAXCOLUMN; x++) {
      GetWindowText(hBWld[(y-1)*BWLD_MAXCOLUMN + (x)], buf, sizeof(buf));
      SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
      if (*buf) {
        wld = WldFind(atol(buf));
        wld->wHWnd = hBWld[y*BWLD_MAXCOLUMN + x];
      }
    }
  }
  
  /* Fill in new row */
  y=0;
  for(x=0; x<BWLD_MAXCOLUMN; x++)
    SetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf);
  y=1;
  for(x=0; x<BWLD_MAXCOLUMN; x++){
    GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
    if (*buf) {
      wld = WldFind(atol(buf));
      if (wld)
        MapPlaceWld(hWnd, wld, x, y);
    }
  }

  /* Correct Exits */
  for(y=0; y<BWLD_MAXROW; y++) {
    for(x=0; x<BWLD_MAXCOLUMN-1; x++) {
      MapEnableExit(hWnd, hBWld[y*BWLD_MAXCOLUMN + x], x, y);
      GetWindowText(hBWld[y*BWLD_MAXCOLUMN + x], buf, sizeof(buf));
      if (*buf) {
        wld = WldFind(atol(buf));
        MapSetExit(hWnd, wld, x, y);
      }
    }
  }
}


/*
 * This should actually be in the PAINT message of the main window
 * but this was more convenient for a quick change
 */
void MapSetActive(HWND hWnd, HWND hNewActive) {
  HDC     hDC;
  HBRUSH  hBrush;
  RECT    rc;
  
  /* erase old box */
  if (hActive) {
    GetWindowRect(hActive, &rc);
    OffsetRect(&rc, -9, -47);
    InflateRect(&rc, 2, 2);
    InvalidateRect(hWnd, &rc, TRUE);
    UpdateWindow(hWnd);
  }
  
  /* draw box around hActive */
  hActive = hNewActive;
  if (hActive) {
    hDC = GetDC(hWnd);
    hBrush = CreateSolidBrush(RGB(255, 0, 0));
    GetWindowRect(hActive, &rc);
    OffsetRect(&rc, -9, -47);
    InflateRect(&rc, 2, 2);
    FrameRect(hDC, &rc, hBrush);
    DeleteObject(hBrush);
    ReleaseDC(hWnd, hDC);
  }
}

void MapClearWld(HWND hWnd, WLD *wld) {
  long pos;
  int  x = 0;
  int  y = 0;

  if (!wld) return;
  if (wld->wHWnd) {
    if (wld->wHWnd == hActive) MapSetActive(hWnd, NULL);
    SetWindowText(wld->wHWnd, "");
    for (pos=0; pos<BWLD_MAXROW*BWLD_MAXCOLUMN; pos++)
      if (hBWld[pos] == wld->wHWnd) {
        x = (int) (pos)%(BWLD_MAXCOLUMN);
        y = (int) (pos)/(BWLD_MAXCOLUMN);
        MapEnableExit(hWnd, wld->wHWnd, x, y);
        break;
      }
  }
}

