

/* NOTE: View with Tabs set to *2* */


/****************************************************************************

    PROGRAM: Generic.c

    PURPOSE: Generic template for Windows applications

    FUNCTIONS:

    WinMain() - calls initialization function, processes message loop
    InitApplication() - initializes window data and registers window
    InitInstance() - saves instance handle and creates main window
    MainWndProc() - processes messages
    AboutProc() - processes messages for "About" dialog box

    COMMENTS:

        Windows can have several copies of your application running at the
        same time.  The variable hInst keeps track of which instance this
        application is so that processing will be to the correct window.

****************************************************************************/

#include <windows.h>              /* required for all Windows applications */
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>           /* technically I should use LPSTR's etc */
#include "wld.h"
#include "map.h"
#include "wldedit.h"              /* specific to this program          */ 
#include "stddesc.h"
#include "pcontrol.h"

HANDLE        hInst;               /* current instance              */
HWND          hWndMain;
HWND          hBWld[BWLD_MAXROW*BWLD_MAXCOLUMN];
HWND          hBHorz[BWLD_MAXROW*(BWLD_MAXCOLUMN-1)];
HWND          hBVert[(BWLD_MAXROW-1)*BWLD_MAXCOLUMN];

long          nNextWld = 100;
OPENFILENAME  ofn;

HWND          hActive = NULL;
WLD *         wActive = NULL;
/* Wld Inspector */
HWND          hToolpad;
HWND          hVirtual;
HWND          hSDesc;
HWND          hDesc;
HFONT         hToolFont;
/* Wld List */
HWND          hListpad;
HWND          hList;
HWND          hListFont;
/* Exit Inspector */
HWND          hExitpad;
DLGPROC       fpExitpadProc;

int           nStdDescList;


/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

    COMMENTS:

        Windows recognizes this function by name as the initial entry point
        for the program.  This function calls the application initialization
        routine, if no other instance of the program is running, and always
        calls the instance initialization routine.  It then executes a message
        retrieval and dispatch loop that is the top-level control structure
        for the remainder of execution.  The loop is terminated when a WM_QUIT
        message is received, at which time this function exits the application
        instance by returning the value passed by PostQuitMessage().

        If this function must abort before entering the message loop, it
        returns the conventional value NULL.

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;                /* current instance         */
HANDLE hPrevInstance;            /* previous instance        */
LPSTR lpCmdLine;                 /* command line             */
int nCmdShow;                    /* show-window type (open/icon) */
{
    MSG msg;                     /* message              */

    if (!hPrevInstance)          /* Other instances of app running? */
    if (!InitApplication(hInstance)) /* Initialize shared things */
        return (FALSE);      /* Exits if unable to initialize     */

    /* Perform initializations that apply to a specific instance */
    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    hActive = NULL;
    wActive = NULL;

    /* Acquire and dispatch messages until a WM_QUIT message is received. */
    while (GetMessage(&msg,    /* message structure              */
        NULL,          /* handle of window receiving the message */
        NULL,          /* lowest message to examine          */
        NULL))         /* highest message to examine         */
    {
    TranslateMessage(&msg);    /* Translates virtual key codes       */
    DispatchMessage(&msg);     /* Dispatches message to window       */
    }
    return (msg.wParam);       /* Returns the value from PostQuitMessage */
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

    COMMENTS:

        This function is called at initialization time only if no other
        instances of the application are running.  This function performs
        initialization tasks that can be done once for any number of running
        instances.

        In this case, we initialize a window class by filling out a data
        structure of type WNDCLASS and calling the Windows RegisterClass()
        function.  Since all instances of this application use the same window
        class, we only need to do this when the first instance is initialized.


****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;                  /* current instance       */
{
  WNDCLASS  wc;
    
  /* Register floating toolpad window class */
  wc.style = NULL;                    /* Class style(s).                    */
  wc.lpfnWndProc = ToolpadWndProc;       /* Function to retrieve messages for  */
  wc.cbClsExtra = 0;                  /* No per-class extra data.           */
  wc.cbWndExtra = 0;                  /* No per-window extra data.          */
  wc.hInstance = hInstance;           /* Application that owns the class.   */
  wc.hIcon = LoadIcon(hInstance, "MYICON");
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = GetStockObject(LTGRAY_BRUSH);  
  wc.lpszMenuName =  NULL;
  wc.lpszClassName = "ToolpadClass"; /* Name used in call to CreateWindow. */
  if (!RegisterClass(&wc))
    return FALSE;
  
             
  /* Register floating wldList window class */
  wc.style = NULL;                    /* Class style(s).                    */
  wc.lpfnWndProc = ListpadWndProc;       /* Function to retrieve messages for  */
  wc.cbClsExtra = 0;                  /* No per-class extra data.           */
  wc.cbWndExtra = 0;                  /* No per-window extra data.          */
  wc.hInstance = hInstance;           /* Application that owns the class.   */
  wc.hIcon = LoadIcon(hInstance, "MYICON");
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = GetStockObject(LTGRAY_BRUSH);  
  wc.lpszMenuName =  NULL;
  wc.lpszClassName = "ListpadClass"; /* Name used in call to CreateWindow. */
  if (!RegisterClass(&wc))
    return FALSE;
  

  /* Fill in window class structure with parameters that describe the       */
  /* main window.                                                           */
      
  wc.style = NULL;                    /* Class style(s).                    */
  wc.lpfnWndProc = MainWndProc;       /* Function to retrieve messages for  */
  wc.cbClsExtra = 0;                  /* No per-class extra data.           */
  wc.cbWndExtra = 0;                  /* No per-window extra data.          */
  wc.hInstance = hInstance;           /* Application that owns the class.   */
  wc.hIcon = LoadIcon(hInstance, "MYICON");
  wc.hCursor = LoadCursor(NULL, IDC_ARROW);
  wc.hbrBackground = GetStockObject(GRAY_BRUSH);  
  wc.lpszMenuName =  "MainMenu";   /* Name of menu resource in .RC file. */
  wc.lpszClassName = "WldEditWClass"; /* Name used in call to CreateWindow. */
      
  /* Register the window class and return success/failure code. */
  return (RegisterClass(&wc));
      
}



/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

    COMMENTS:

        This function is called at initialization time for every instance of
        this application.  This function performs initialization tasks that
        cannot be shared by multiple instances.

        In this case, we save the instance handle in a static variable and
        create and display the main program window.

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;          /* Current instance identifier.       */
    int             nCmdShow;           /* Param for first ShowWindow() call. */
{
    /* Save the instance handle in static variable, which will be used in  */
    /* many subsequence calls from this application to Windows.            */

    hInst = hInstance;

    /* Create a main window for this application instance.  */
    hWndMain = CreateWindow(
        "WldEditWClass",                /* See RegisterClass() call.          */
        "Area Editor",                  /* Text for window title bar.         */
        WS_OVERLAPPED|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX|WS_THICKFRAME, 
        5,                              /* Default horizontal position.       */
        5,                              /* Default vertical position.         */
        635,                            /* width.                     */
        475,                            /* height.                    */
        NULL,                           /* Overlapped windows have no parent. */
        NULL,                           /* Use the window class menu.         */
        hInstance,                      /* This instance owns this window.    */
        NULL                            /* Pointer not needed.                */
    );

    /* If window could not be created, return "failure" */

    if (!hWndMain) {
        MessageBox(NULL, "AGGGHGHGH!!!!!!!", "Unable to Open Application Window", MB_OK);
        return (FALSE);
    }

    /* Make the window visible; update its client area; and return "success" */
    ShowWindow(hWndMain, nCmdShow);  /* Show the window                        */
    UpdateWindow(hWndMain);          /* Sends WM_PAINT message */
    
    return (TRUE);               /* Returns the value from PostQuitMessage */
}

void ApplicationExit(void) {
  WldFreeAll();
  StdDescFreeAll();
  PostQuitMessage(0);     /* Quit the App... */
}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, UINT, WPARAM, LPARAM)

****************************************************************************/

long CALLBACK __export MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;                      /* window handle                 */
UINT message;                   /* type of message               */
WPARAM wParam;                  /* additional information        */
LPARAM lParam;                  /* additional information        */
{
  FARPROC fpProc;

  switch (message) {
  case WM_CREATE: {
    int x,y;
  
    /* Init StdDesc data storage */
    StdDescInit();
    StdDescRead(hWnd);
    
    /* Init Wld structure data storage */
    WldInit();

    /* Toolpad */
    hToolpad = CreateWindow("ToolpadClass", "Wld Inspector",
      WS_OVERLAPPED|WS_BORDER|WS_CAPTION|WS_VISIBLE,
      30, 450, 580, 145,
      hWnd, NULL, hInst, NULL);

    /* Listpad */
    hListpad = CreateWindow("ListpadClass", "Wld List",
      WS_OVERLAPPED|WS_BORDER|WS_CAPTION|WS_VISIBLE,
      630, 5, 168, 590,
      hWnd, NULL, hInst, NULL);

    /* Exitpad */
    fpExitpadProc = (DLGPROC) MakeProcInstance(ExitpadWndProc, hInst);
    hExitpad = CreateDialog(hInst, "EXITPAD", hWnd, fpExitpadProc);

    /* room buttons */
    for (x=0; x<BWLD_MAXCOLUMN; x++) {
      for (y=0; y<BWLD_MAXROW; y++) {
        /* Create Grid of Buttons */
        hBWld[y*BWLD_MAXCOLUMN+x] = CreateWindow("BUTTON", "",
          WS_CHILD|WS_VISIBLE,
          x*45, y*29, 30, 15,
          hWnd, IDC_BWLD+y*BWLD_MAXCOLUMN+x, hInst, NULL);
      }
    }
    /* horizontal exit buttons */
    for (x=0; x<BWLD_MAXCOLUMN-1; x++) {
      for (y=0; y<BWLD_MAXROW; y++) {
        hBHorz[y*(BWLD_MAXCOLUMN-1)+x] = 0;
      }
    }
    /* vertical exit buttons */
    for (x=0; x<BWLD_MAXCOLUMN; x++) {
      for (y=0; y<BWLD_MAXROW-1; y++) {
        hBVert[y*BWLD_MAXCOLUMN+x] = 0;
      }
    }
    break;  
  }

  case WM_COMMAND: {      /* message: command from application menu */
     /* clicked on a world button */
    if (wParam>=IDC_BWLD && wParam<IDC_BWLD+BWLD_MAXROW*BWLD_MAXCOLUMN) {
      char  buf[256];
      char  title[256];
      char  desc[512];
      long  virtual;
      int   x;
      int   y;
    
      /* set new active wld */
      if (WldCount()<1) { /* first one */
        GetWindowText(hVirtual,buf,sizeof(buf));
        nNextWld = atol(buf);
        if (nNextWld<0) nNextWld=100;
      }
      MapSetActive(hWnd, hBWld[wParam-IDC_BWLD]); /* Sets hActive, draw highlight box */
      GetWindowText(hActive, buf, sizeof(buf));
      x = (wParam-IDC_BWLD)%(BWLD_MAXCOLUMN);
      y = (wParam-IDC_BWLD)/(BWLD_MAXCOLUMN);
      if (*buf) { /* Clicked on an existing Wld */
        /* update toolbar to show this World Structure*/
        virtual = atol(buf);
        wActive = WldFind(virtual);
        WldSelect(wActive);
        ToolpadPaste(wActive);
        ExitpadPaste(wActive);
      } else {
        /* Clicked a blank square */
        if (!wActive || wActive->wHWnd) { /* create a new map entry clone active wld */
          GetWindowText(hSDesc, title, sizeof(title));
          GetWindowText(hDesc,  desc,  sizeof(desc));
          virtual = nNextWld;
          nNextWld++;
          sprintf(buf, "%ld", virtual);
          SetWindowText(hActive, buf);
          if (!wActive)
            wActive = WldCreate(virtual, title, desc);
          else
            wActive = WldCreateCopy(virtual, wActive);
          wActive->wHWnd = hActive;
          WldSelect(wActive);
          MapEnableExit(hWnd, hActive, x, y);
          ToolpadPaste(wActive);
          ExitpadPaste(wActive);
        } else {  /* didnt exist on map place it */
          MapPlaceWld(hWnd, wActive, x, y);
        }
        
        sprintf(buf, "%ld ", virtual);
        SendMessage(hList, LB_SELECTSTRING, 0, (LPARAM)( (LPCSTR)buf ));
      }
    }
    
     /* horizontal exit */
    else if (wParam>=IDC_BHORZ && wParam<IDC_BHORZ+BWLD_MAXROW*(BWLD_MAXCOLUMN-1)) {
      char  buf[32];
      int   x;
      int   y;
      WLD  *west;
      WLD  *east;
      
      x = (wParam-IDC_BHORZ)%(BWLD_MAXCOLUMN-1);
      y = (wParam-IDC_BHORZ)/(BWLD_MAXCOLUMN-1);
      /* get pointers to WLD's */
      GetWindowText(hBWld[(x+1)+y*BWLD_MAXCOLUMN], buf, sizeof(buf));
      west = WldFind(atol(buf));
      GetWindowText(hBWld[x+y*BWLD_MAXCOLUMN], buf, sizeof(buf));
      east = WldFind(atol(buf));
      if (!east || !west) {
        MessageBox(NULL, "AGH", "No East or West!", MB_OK);
        break;
      }

      /* add/remove link */
      GetWindowText(hBHorz[wParam-IDC_BHORZ], buf, sizeof(buf));
      if (buf[0]=='\0') {
        /* Add link */
        SetWindowText(hBHorz[wParam-IDC_BHORZ], "X");
        east->wEDir[EDIR_EAST].eVirtual = west->wVirtual;
        west->wEDir[EDIR_WEST].eVirtual = east->wVirtual;
      } else {
        /* remove link */
        SetWindowText(hBHorz[wParam-IDC_BHORZ], "");
        east->wEDir[EDIR_EAST].eVirtual = 0;
        west->wEDir[EDIR_WEST].eVirtual = 0;
      }
      ExitpadPaste(wActive); /* update exitpad if its changed */
    }
    
     /* vertical exit */
    else if (wParam>=IDC_BVERT && wParam<IDC_BVERT+(BWLD_MAXROW-1)*BWLD_MAXCOLUMN) {
      char  buf[32];
      int   x;
      int   y;
      WLD  *north;
      WLD  *south;
      
      x = (wParam-IDC_BVERT)%(BWLD_MAXCOLUMN);
      y = (wParam-IDC_BVERT)/(BWLD_MAXCOLUMN);
      /* get pointers to WLD's */
      GetWindowText(hBWld[x+y*BWLD_MAXCOLUMN], buf, sizeof(buf));
      south = WldFind(atol(buf));
      GetWindowText(hBWld[x+(y+1)*BWLD_MAXCOLUMN], buf, sizeof(buf));
      north = WldFind(atol(buf));
      if (!north || !south) {
        MessageBox(NULL, "AGH", "No North or South!", MB_OK);
        break;
      }
      
      /* add/remove link */
      GetWindowText(hBVert[wParam-IDC_BVERT], buf, sizeof(buf));
      if (buf[0]=='\0') {
        /* Add link */
        SetWindowText(hBVert[wParam-IDC_BVERT], "X");
        south->wEDir[EDIR_SOUTH].eVirtual = north->wVirtual;
        north->wEDir[EDIR_NORTH].eVirtual = south->wVirtual;
      } else {
        /* remove link */
        SetWindowText(hBVert[wParam-IDC_BVERT], "");
        south->wEDir[EDIR_SOUTH].eVirtual = 0;
        north->wEDir[EDIR_NORTH].eVirtual = 0;
      }
      ExitpadPaste(wActive); /* update exitpad if its changed */
    }

    /* chose a Std Desc Menu item */    
    else if (wParam>=IDM_STDDESC && wParam<IDM_STDDESC+((WPARAM)stdDescMax)) {
      STDDESC *stdDesc;
      char    buf[256];
      
      stdDesc = StdDescFind(wParam-IDM_STDDESC);
      if (wActive) {
        if (stdDesc) {
          strcpy(wActive->wSDesc, stdDesc->sTitle);
          strcpy(wActive->wDesc,  stdDesc->sDesc);
          /* update toolbar to show this World Structure*/
          ToolpadPaste(wActive);
          ExitpadPaste(wActive);
        }
      } else if (stdDesc){
        WLD     test;

        GetWindowText(hVirtual,buf,sizeof(buf));
        test.wVirtual = atol(buf);
        strcpy(test.wSDesc, stdDesc->sTitle);
        strcpy(test.wDesc,  stdDesc->sDesc);
        ToolpadPaste(&test);
        ExitpadPaste(&test);
        MapSetActive(hWnd, NULL);
        wActive = NULL;
      }
    }

    else switch (wParam) {
    case IDM_FILE_SAVEAS: {
      char  szDirName[256];
      char  szFile[256];
      char  szFileTitle[256];
      UINT  i;
      UINT  cbString;
      char  chReplace;    /* string separator for szFilter */
      char  szFilter[256];
      
      /*
      * Set default directory
      */
      /* GetSystemDirectory(szDirName, sizeof(szDirName)); */
      strcpy(szDirName, ".");
      
      /* Look up filename specs */
      if ((cbString = LoadString(hInst, IDS_FILTERSTRING,
        szFilter, sizeof(szFilter))) == 0) {
        /* ErrorHandler(); */
        return 0;
      }
      chReplace = szFilter[cbString - 1]; /* retrieve wildcard */
      for (i = 0; szFilter[i] != '\0'; i++) {
        if (szFilter[i] == chReplace)
          szFilter[i] = '\0';
      }
      
      /* Set all structure members to zero. */
      memset(&ofn, 0, sizeof(OPENFILENAME));
      
      /* Initialize the OPENFILENAME members. */
      szFile[0] = '\0';
      ofn.lStructSize = sizeof(OPENFILENAME);
      ofn.hwndOwner = hWnd;
      ofn.lpstrFilter = szFilter;
      ofn.lpstrFile= szFile;
      ofn.nMaxFile = sizeof(szFile);
      ofn.lpstrFileTitle = szFileTitle;
      ofn.nMaxFileTitle = sizeof(szFileTitle);
      ofn.lpstrInitialDir = szDirName;
      ofn.Flags = OFN_HIDEREADONLY;
      
      if (GetSaveFileName(&ofn)) {
        ToolpadCopy(wActive); /* write any current changes */
        ExitpadCopy(wActive); /* write any current changes */
        WldSave(ofn.lpstrFile);
        MapSave(ofn.lpstrFile);    
      } else {
        /* ErrorHandler(); */
      }
      return (NULL);
      break;
    }
        
    case IDM_FILE_OPEN: {
      char  szDirName[256];
      char  szFile[256];
      char  szFileTitle[256];
      UINT  i;
      UINT  cbString;
      char  chReplace;    /* string separator for szFilter */
      char  szFilter[256];
      long  virtual;
      char  buf[256];
      
      
      /*
      * Set default directory
      */
      /* GetSystemDirectory(szDirName, sizeof(szDirName)); */
      strcpy(szDirName, ".");
      
      /* Look up filename specs */
      if ((cbString = LoadString(hInst, IDS_FILTERSTRING,
        szFilter, sizeof(szFilter))) == 0) {
        /* ErrorHandler(); */
        return 0;
      }
      chReplace = szFilter[cbString - 1]; /* retrieve wildcard */
      for (i = 0; szFilter[i] != '\0'; i++) {
        if (szFilter[i] == chReplace)
          szFilter[i] = '\0';
      }
      
      /* Set all structure members to zero. */
      memset(&ofn, 0, sizeof(OPENFILENAME));
      
      /* Initialize the OPENFILENAME members. */
      szFile[0] = '\0';
      ofn.lStructSize = sizeof(OPENFILENAME);
      ofn.hwndOwner = hWnd;
      ofn.lpstrFilter = szFilter;
      ofn.lpstrFile= szFile;
      ofn.nMaxFile = sizeof(szFile);
      ofn.lpstrFileTitle = szFileTitle;
      ofn.nMaxFileTitle = sizeof(szFileTitle);
      ofn.lpstrInitialDir = szDirName;
      ofn.Flags = OFN_HIDEREADONLY;
      
      if (GetOpenFileName(&ofn)) {
        WldOpen(ofn.lpstrFile);
        MapOpen(hWnd, ofn.lpstrFile);
        
        /* Point toolpad to first structure */
        for (i=0; i<BWLD_MAXCOLUMN*BWLD_MAXROW; i++) {
          if (hBWld[i]) {
            GetWindowText(hBWld[i], buf, sizeof(buf));
            if (*buf) {
              virtual = atol(buf);
              MapSetActive(hWnd, hBWld[i]);
              wActive = WldFind(virtual);
              ToolpadPaste(wActive);
              ExitpadPaste(wActive);
              /* select appropriate list entry */
              sprintf(buf, "%ld ", wActive->wVirtual);
              SendMessage(hList, LB_SELECTSTRING, (WPARAM)-1, (LPARAM)((LPCSTR)buf));
            }
            break;
          }
        }
      } else {
        /* ErrorHandler(); */
      }
      return (NULL);
      break;
    }
        
    case IDM_FILE_EXIT:
      ApplicationExit();
      return (NULL);
      break;
        
    case IDM_EDIT_CLEARMAP:
      MapClear(hWnd);
      break;
  
    case IDM_VIEW_WLDINSPECTOR: {
      HMENU hMenu;
      BOOL  isChecked;
      
      /* Retrieve a handle to the Help menu. */
      hMenu = GetSubMenu(GetMenu(hWnd), 2);
      /* Retrieve the current state of the item. */
      isChecked = GetMenuState(hMenu, IDM_VIEW_WLDINSPECTOR, MF_BYCOMMAND) & MF_CHECKED;
      
      /* Toggle the state of the item. */
      if (isChecked) {
        CheckMenuItem(hMenu, IDM_VIEW_WLDINSPECTOR, MF_BYCOMMAND|MF_UNCHECKED);
        /* set hToolpad to invisible */
        ShowWindow(hToolpad, SW_HIDE);
      } else {
        CheckMenuItem(hMenu, IDM_VIEW_WLDINSPECTOR, MF_BYCOMMAND|MF_CHECKED);
        /* set hToolpad to visible */
        ShowWindow(hToolpad, SW_SHOW);
      }     
      break;
    }
  
    case IDM_VIEW_WLDLIST: {
      HMENU hMenu;
      BOOL  isChecked;
      
      /* Retrieve a handle to the Colors menu. */
      hMenu = GetSubMenu(GetMenu(hWnd), 2);
      /* Retrieve the current state of the item. */
      isChecked = GetMenuState(hMenu, IDM_VIEW_WLDLIST, MF_BYCOMMAND) & MF_CHECKED;
      
      /* Toggle the state of the item. */
      if (isChecked) {
        CheckMenuItem(hMenu, IDM_VIEW_WLDLIST, MF_BYCOMMAND|MF_UNCHECKED);
        /* set hToolpad to invisible */
        ShowWindow(hListpad, SW_HIDE);
      } else {
        CheckMenuItem(hMenu, IDM_VIEW_WLDLIST, MF_BYCOMMAND|MF_CHECKED);
        /* set hToolpad to visible */
        ShowWindow(hListpad, SW_SHOW);
      }     
      break;
    }
  
    case IDM_VIEW_EXITINSPECTOR: {
      HMENU hMenu;
      BOOL  isChecked;
      
      /* Retrieve a handle to the Colors menu. */
      hMenu = GetSubMenu(GetMenu(hWnd), 2);
      /* Retrieve the current state of the item. */
      isChecked = GetMenuState(hMenu, IDM_VIEW_EXITINSPECTOR, MF_BYCOMMAND) & MF_CHECKED;
      
      /* Toggle the state of the item. */
      if (isChecked) {
        CheckMenuItem(hMenu, IDM_VIEW_EXITINSPECTOR, MF_BYCOMMAND|MF_UNCHECKED);
        /* set hToolpad to invisible */
        ShowWindow(hExitpad, SW_HIDE);
      } else {
        CheckMenuItem(hMenu, IDM_VIEW_EXITINSPECTOR, MF_BYCOMMAND|MF_CHECKED);
        /* set hToolpad to visible */
        ShowWindow(hExitpad, SW_SHOW);
      }     
      break;
    }
  
    case IDM_NEWSTDDESC: {
      char  title[256];
      char  desc[512];
    
      GetWindowText(hSDesc, title, sizeof(title));
      GetWindowText(hDesc,  desc,  sizeof(desc));
      StdDescCreate(hWnd, title, desc);
      StdDescSave();
      break;
    }
    
    case IDM_DELETESTDDESC: {
      if (DialogBox(hInst,      /* current instance          */
          "DeleteStdDesc",      /* resource to use           */
          hWnd,             /* parent handle             */
          DeleteStdDescProc)) { /* AboutProc() instance address  */
        /* clicked delete not cancel */
        StdDescDelete(hWnd, nStdDescList);
        StdDescSave();
      }
      break;
    }
    
    case IDM_SHIFT_LEFT:
      MapShiftLeft(hWnd);
      break;
  
    case IDM_SHIFT_RIGHT:
      MapShiftRight(hWnd);
      break;
  
    case IDM_SHIFT_UP:
      MapShiftUp(hWnd);
      break;
  
    case IDM_SHIFT_DOWN:
      MapShiftDown(hWnd);
      break;
  
    case IDM_HELP_ABOUT:
      fpProc = MakeProcInstance(AboutProc, hInst);
      DialogBox(hInst,    /* current instance          */
        "AboutBox",      /* resource to use           */
        hWnd,            /* parent handle             */
        AboutProc);      /* AboutProc() instance address  */
      FreeProcInstance( fpProc );
      break;

    case IDM_HELP_README: {
      HANDLE theInst;
      HMENU hMenu;
      
      /* Retrieve a handle to the Help menu. */
      hMenu = GetSubMenu(GetMenu(hWnd), 5);
      ShowWindow(hWnd, SW_HIDE);
      ShowWindow(hToolpad, SW_HIDE);
      ShowWindow(hListpad, SW_HIDE);
      theInst = WinExec("NOTEPAD.EXE README.TXT", SW_SHOWNORMAL);
      if (theInst>=32) WaitTillInstFinished(theInst);
      ShowWindow(hWnd, SW_SHOW);
      if (GetMenuState(hMenu, IDM_VIEW_WLDINSPECTOR, MF_BYCOMMAND) & MF_CHECKED)
        ShowWindow(hToolpad, SW_SHOW);
      if (GetMenuState(hMenu, IDM_VIEW_WLDLIST, MF_BYCOMMAND) & MF_CHECKED)
        ShowWindow(hListpad, SW_SHOW);
      break;
    }
  
    default:                    /* Lets Windows process it   */
      return (DefWindowProc(hWnd, message, wParam, lParam));
      break;
    } /* switch wParam */

    break;
  }
  
  /* Perform special drawing, let windows do the rest */
  case WM_PAINT: {
    return (DefWindowProc(hWnd, message, wParam, lParam));
    break;
  }
    
  case WM_DESTROY:          /* message: window being destroyed */
    DefWindowProc(hWnd, message, wParam, lParam);
    ApplicationExit();
    if (fpExitpadProc) {
      FreeProcInstance(fpExitpadProc);
    }
    break;

  default:                  /* Passes it on if unproccessed    */
    return (DefWindowProc(hWnd, message, wParam, lParam));
  }
  return (NULL);
}


/****************************************************************************/

/* read settings from Toolpad */

void ToolpadCopy(WLD *wld) {
  char  buf[256];
  char  title[256];
  char  desc[512];
  int   i;

  if (wld) {
    GetWindowText(hSDesc, title, sizeof(title));
    GetWindowText(hDesc,  desc,  sizeof(desc));
    strcpy(wld->wSDesc, title);
    strcpy(wld->wDesc,  desc);
    
    /* Delete old Wld List Entry */
    sprintf(buf, "%ld ", wld->wVirtual);
    i = (int) SendMessage(hList, LB_FINDSTRING, (WPARAM)-1, (LPARAM)((LPCSTR)buf));
    SendMessage(hList, LB_DELETESTRING, i, 0);
    /* Add updated Wld List Entry  & select it */
    sprintf(buf, "%ld %s", wld->wVirtual, wld->wSDesc);
    SendMessage(hList, LB_ADDSTRING, (WPARAM)-1, (LPARAM)((LPCSTR)buf));
    sprintf(buf, "%ld ", wld->wVirtual);
    SendMessage(hList, LB_SELECTSTRING, (WPARAM)-1, (LPARAM)((LPCSTR)buf));
  }
}

void ToolpadPaste(WLD *wld) {
  char  buf[256];

  if (wld) {
    sprintf(buf, "%ld", wld->wVirtual);
    SetWindowText(hVirtual,buf);
    SetWindowText(hSDesc,  wld->wSDesc);
    SetWindowText(hDesc,   wld->wDesc);
    InvalidateRect(hToolpad, NULL, TRUE);
  }
}

void ExitpadCopy(WLD *wld) {
  char buf[256];

  if (wld) {
    GetDlgItemText(hExitpad, IDC_EDIT_NORTH, buf, sizeof(buf));
    wld->wEDir[EDIR_NORTH].eVirtual = atol(buf);
    GetDlgItemText(hExitpad, IDC_EDIT_EAST, buf, sizeof(buf));
    wld->wEDir[EDIR_EAST].eVirtual = atol(buf);
    GetDlgItemText(hExitpad, IDC_EDIT_SOUTH, buf, sizeof(buf));
    wld->wEDir[EDIR_SOUTH].eVirtual = atol(buf);
    GetDlgItemText(hExitpad, IDC_EDIT_WEST, buf, sizeof(buf));
    wld->wEDir[EDIR_WEST].eVirtual = atol(buf);
    GetDlgItemText(hExitpad, IDC_EDIT_UP, buf, sizeof(buf));
    wld->wEDir[EDIR_UP].eVirtual = atol(buf);
    GetDlgItemText(hExitpad, IDC_EDIT_DOWN, buf, sizeof(buf));
    wld->wEDir[EDIR_DOWN].eVirtual = atol(buf);
  }
}

void ExitpadPaste(WLD *wld) {
  char buf[256];

  if (wld) {
    sprintf(buf, "%ld", wld->wEDir[EDIR_NORTH].eVirtual);
    SetDlgItemText(hExitpad, IDC_EDIT_NORTH,  buf);
    sprintf(buf, "%ld", wld->wEDir[EDIR_EAST].eVirtual);
    SetDlgItemText(hExitpad, IDC_EDIT_EAST,   buf);
    sprintf(buf, "%ld", wld->wEDir[EDIR_SOUTH].eVirtual);
    SetDlgItemText(hExitpad, IDC_EDIT_SOUTH,  buf);
    sprintf(buf, "%ld", wld->wEDir[EDIR_WEST].eVirtual);
    SetDlgItemText(hExitpad, IDC_EDIT_WEST,   buf);
    sprintf(buf, "%ld", wld->wEDir[EDIR_UP].eVirtual);
    SetDlgItemText(hExitpad, IDC_EDIT_UP,     buf);
    sprintf(buf, "%ld", wld->wEDir[EDIR_DOWN].eVirtual);
    SetDlgItemText(hExitpad, IDC_EDIT_DOWN,   buf);
    InvalidateRect(hExitpad, NULL, TRUE);
  }
}



long CALLBACK __export ToolpadWndProc(hWnd, message, wParam, lParam)
HWND hWnd;                      /* window handle                 */
UINT message;                   /* type of message               */
WPARAM wParam;                  /* additional information        */
LPARAM lParam;                  /* additional information        */
{

  switch (message) {
  case WM_CREATE: {
    LOGFONT   lFont;

    hVirtual = CreateWindow("EDIT", "100",
      WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL|ES_LEFT|WS_TABSTOP,
      5, 5, 50, 20,
      hWnd, IDC_VIRTUAL, hInst, NULL);
    hSDesc = CreateWindow("EDIT", "",
      WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL|ES_LEFT|WS_TABSTOP,
      60, 5, 515, 20,
      hWnd, IDC_SDESC, hInst, NULL);
    hDesc  = CreateWindow("EDIT", "",
      WS_CHILD|WS_VISIBLE|WS_BORDER|ES_AUTOHSCROLL|ES_LEFT|ES_MULTILINE|ES_WANTRETURN|WS_TABSTOP,
      5, 30, 570, 90,
      hWnd, IDC_DESC, hInst, NULL);

    /* Change font to courier fixed pitch font */
    hToolFont = (HFONT) NULL;
    memset(&lFont, 0, sizeof(lFont));
    lFont.lfHeight = -11;
    lFont.lfWeight = FW_DONTCARE;
    strcpy(lFont.lfFaceName, "Courier New");
    if (hToolFont = CreateFontIndirect((LPLOGFONT) &lFont)) {
      SendMessage(hVirtual, WM_SETFONT,(WPARAM) hToolFont, 0);
      SendMessage(hSDesc,   WM_SETFONT,(WPARAM) hToolFont, 0);
      SendMessage(hDesc,    WM_SETFONT,(WPARAM) hToolFont, 0);
    }

    break;
  }

  case WM_COMMAND:       /* message: command from application menu */
    switch (wParam) {
    default:                    /* Lets Windows process it   */
      return (DefWindowProc(hWnd, message, wParam, lParam));
      break;
    } /* switch wParam */

  case WM_PAINT: {
    /* Perform special drawing */           
    /* let windows do the rest */
    return (DefWindowProc(hWnd, message, wParam, lParam));
    break;
  }
    
  /* When the focus is stolen away from the toolpad 
   * update the memory of the wld struct with any changes
   */
  case WM_ACTIVATE:
    DefWindowProc(hWnd, message, wParam, lParam);
    if (wParam==WA_INACTIVE && wActive) {
      ToolpadCopy(wActive);
    }
    break;
    
  case WM_DESTROY:
    DefWindowProc(hWnd, message, wParam, lParam);
    if (hToolFont)
      DeleteObject(hToolFont);
    break;

  default:                  /* Passes it on if unproccessed    */
    return (DefWindowProc(hWnd, message, wParam, lParam));
  }
  return (NULL);
}


/****************************************************************************/

long CALLBACK __export ListpadWndProc(hWnd, message, wParam, lParam)
HWND hWnd;                      /* window handle                 */
UINT message;                   /* type of message               */
WPARAM wParam;                  /* additional information        */
LPARAM lParam;                  /* additional information        */
{

  switch (message) {
  case WM_CREATE: {
    LOGFONT   lFont;

    hList = CreateWindow("LISTBOX", "",
      WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|WS_VSCROLL
        |LBS_SORT|LBS_NOTIFY|LBS_WANTKEYBOARDINPUT,
      5, 5, 155, 560,
      hWnd, IDC_WLDLIST, hInst, NULL);

    /* Change font to courier fixed pitch font */
    hListFont = (HFONT) NULL;
    memset(&lFont, 0, sizeof(lFont));
    lFont.lfHeight = -11;
    lFont.lfWeight = FW_DONTCARE;
    strcpy(lFont.lfFaceName, "Courier New");
    if (hListFont = CreateFontIndirect((LPLOGFONT) &lFont)) {
      SendMessage(hList, WM_SETFONT,(WPARAM) hListFont, 0);
    }

    break;
  }

  case WM_VKEYTOITEM:       /* message: character */
    switch (wParam) { /* Key codes */

    case VK_DELETE: {
      int     i;
      char    buf[256];

      i = (int) HIWORD(lParam);
      SendMessage(hList, LB_GETTEXT, i, (LPARAM)((LPCSTR) buf));
      for (i=0; buf[i] && buf[i]!=' '; i++); buf[i] = 0;
      MapClearWld(GetParent(hWnd), WldFind(atol(buf)));
      WldFree(atol(buf));

      /* Fix up the list pad */
      SendMessage(hList, LB_DELETESTRING, i, 0);
      if (SendMessage(hList, LB_SETCURSEL, i, 0)!=LB_ERR) {
        SendMessage(hList, LB_GETTEXT, i, (LPARAM)((LPCSTR) buf));
        for (i=0; buf[i] && buf[i]!=' '; i++); buf[i] = 0;
        wActive = WldFind(atol(buf));
        MapSetActive(hWndMain, wActive->wHWnd);
        ToolpadPaste(wActive); /* point toolpad to new wld struct */
        ExitpadPaste(wActive);
      }
      return -2; /* We handled it */
    }

    default:
      return -1; /* We did nothing */
    }
    break;
    
  case WM_COMMAND:       /* message: command from application menu */
    switch (wParam) {
    
    case IDC_WLDLIST: {
      /* LOWORD(lParam) is the Control Handle */
      switch(HIWORD(lParam)) {
      case LBN_SELCHANGE: {
        int     i;
        char    buf[256];
      
        /* Toolpad Copy alters the selection get cursel now */
        i = (int) SendMessage(hList, LB_GETCURSEL, 0, 0);
        ToolpadCopy(wActive); /* the old settings from the toolpad to mem. */
        ExitpadCopy(wActive);
        SendMessage(hList, LB_GETTEXT, i, (LPARAM)((LPCSTR) buf));
        for (i=0; buf[i] && buf[i]!=' '; i++); buf[i] = 0;
        wActive = WldFind(atol(buf));
        MapSetActive(hWndMain, wActive->wHWnd);
        ToolpadPaste(wActive); /* point toolpad to new wld struct */
        ExitpadPaste(wActive);
        /* reselect what they clicked on */
        sprintf(buf, "%ld ", wActive->wVirtual);
        SendMessage(hList, LB_SELECTSTRING, 0, (LPARAM)( (LPCSTR)buf ));
        break;
      }
        
      }
      break;
    }
    
    default:                    /* Lets Windows process it   */
      return (DefWindowProc(hWnd, message, wParam, lParam));
      break;
    } /* switch wParam */

  case WM_PAINT: {
    /* Perform special drawing */           
    /* let windows do the rest */
    return (DefWindowProc(hWnd, message, wParam, lParam));
    break;
  }
    
  case WM_DESTROY:
    DefWindowProc(hWnd, message, wParam, lParam);
    if (hListFont)
      DeleteObject(hListFont);
    break;

  default:                  /* Passes it on if unproccessed    */
    return (DefWindowProc(hWnd, message, wParam, lParam));
  }
  return (NULL);
}



/****************************************************************************/

BOOL __export CALLBACK AboutProc(hDlg, message, wParam, lParam)
HWND hDlg;               /* window handle of the dialog box */
unsigned message;        /* type of message                 */
WORD wParam;             /* message-specific information    */
LONG lParam;
{
  switch (message){
  case WM_INITDIALOG:            /* message: initialize dialog box */
    return (TRUE);
  
  case WM_COMMAND:               /* message: received a command */
    if (wParam == IDOK         /* "OK" box selected?          */
    || wParam == IDCANCEL) /* System menu close command?  */
    {
    EndDialog(hDlg, (wParam==IDOK)); /* Exits the dialog box        */
    return (TRUE);
    }
    break;
  }
  return (FALSE);               /* Didn't process a message    */
}

/****************************************************************************/

BOOL __export CALLBACK DeleteStdDescProc(hDlg, message, wParam, lParam)
HWND hDlg;               /* window handle of the dialog box */
unsigned message;        /* type of message                 */
WORD wParam;             /* message-specific information    */
LONG lParam;
{
  switch (message){
  case WM_INITDIALOG:            /* message: initialize dialog box */
    StdDescAddItems(hDlg, IDC_STDDESCLIST);
    return (TRUE);
  
  case WM_COMMAND:               /* message: received a command */
    if (wParam == IDOK || wParam == IDCANCEL) { /* "OK" box selected?          */
      nStdDescList = (int)SendDlgItemMessage(hDlg, IDC_STDDESCLIST, CB_GETCURSEL, 0, 0);
      EndDialog(hDlg, (wParam==IDOK)); /* Exits the dialog box        */
      return (TRUE);
    }
    break;
  }
  return (FALSE);               /* Didn't process a message    */
}

/****************************************************************************/

BOOL __export CALLBACK ExitpadWndProc(hDlg, message, wParam, lParam)
HWND hDlg;               /* window handle of the dialog box */
unsigned message;        /* type of message                 */
WORD wParam;             /* message-specific information    */
LONG lParam;
{
  switch (message){
  case WM_INITDIALOG:            /* message: initialize dialog box */
    return (TRUE);
  
  /* When the focus is stolen away from the toolpad 
   * update the memory of the wld struct with any changes
   */
  case WM_ACTIVATE:
    if (wParam==WA_INACTIVE && wActive) {
      ExitpadCopy(wActive);
    }
    break;
    
  case WM_COMMAND:               /* message: received a command */
    switch (wParam) {
    char  buf[256];
    
    case IDC_GO_NORTH:
    case IDC_GO_EAST:
    case IDC_GO_SOUTH:
    case IDC_GO_WEST:
    case IDC_GO_UP:
    case IDC_GO_DOWN:
      ExitpadCopy(wActive); /* update any changes to memory */
      if (wParam==IDC_GO_NORTH) GetDlgItemText(hExitpad, IDC_EDIT_NORTH, buf, sizeof(buf));  
      if (wParam==IDC_GO_EAST) GetDlgItemText(hExitpad, IDC_EDIT_EAST, buf, sizeof(buf));  
      if (wParam==IDC_GO_SOUTH) GetDlgItemText(hExitpad, IDC_EDIT_SOUTH, buf, sizeof(buf));  
      if (wParam==IDC_GO_WEST) GetDlgItemText(hExitpad, IDC_EDIT_WEST, buf, sizeof(buf));  
      if (wParam==IDC_GO_UP) GetDlgItemText(hExitpad, IDC_EDIT_UP, buf, sizeof(buf));  
      if (wParam==IDC_GO_DOWN) GetDlgItemText(hExitpad, IDC_EDIT_DOWN, buf, sizeof(buf));  
      wActive = WldFind(atol(buf));
      if (!wActive) {
        MapSetActive(hWndMain, NULL);
        break;
      }
      MapSetActive(hWndMain, wActive->wHWnd);
      ToolpadPaste(wActive); /* point toolpad to new wld struct */
      ExitpadPaste(wActive); /* point exitpad to new wld struct */
      /* Update listpad */
      sprintf(buf, "%ld ", wActive->wVirtual);
      SendMessage(hList, LB_SELECTSTRING, 0, (LPARAM)( (LPCSTR)buf ));
      break;
    }
    break;
  }
  return (FALSE);               /* Didn't process a message    */
}

/****************************************************************************/
