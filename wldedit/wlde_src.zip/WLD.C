#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "wld.h"
#include "wldedit.h"

WLD     *wldList[WLD_MAX];
ATTACH  *attachList;
HGLOBAL  hAttachList;
long     wldMax;

int revDir[] = {
 EDIR_SOUTH,
 EDIR_WEST,
 EDIR_NORTH,
 EDIR_EAST,
 EDIR_DOWN,
 EDIR_UP
};

void WldInit(void) {
  wldMax = 0;
  memset(wldList, 0, sizeof(WLD *)*WLD_MAX);
  hAttachList = GlobalAlloc(GPTR, (DWORD)sizeof(ATTACH)*(DWORD)ATTACH_MAX);
  attachList = (ATTACH*)GlobalLock(hAttachList);
  if (!attachList) {
    MessageBox(GetFocus(), "Unable to allocate attachList\nAttachments will be unsupported for this session", "WldInit Failure", MB_OK);
  }
}

WLD *WldAlloc(void) {
  WLD *wld = NULL;
  int  e;

  if (wldMax<WLD_MAX) {
    wld = malloc(sizeof(WLD));
    memset(wld, 0, sizeof(WLD));
    for (e=0; e<EDIR_MAX; e++) {
      strcpy(wld->wEDir[e].eFlag, "0");
      wld->wEDir[e].eKeyNum = -1;
    }
    if (!wld){
      MessageBox(NULL, "WldAlloc failure!! out of memory", "Error", MB_OK);
      return NULL;
    }

  } else 
    MessageBox(NULL, "WldAlloc failure!! WLD_MAX exceeded", "Error", MB_OK);
    
  return wld;
}

WLD *WldCreate(long virtual, char *title, char *desc) {
  WLD *wld = NULL;
  char buf[256];

  wld = WldAlloc();
  if (!wld){
    MessageBox(NULL, "WldCreate failure!! out of memory", "Error", MB_OK);
    return NULL;
  }
  wldList[wldMax] = wld;
  wldMax++;
  wld->wVirtual = virtual;
  strcpy(wld->wSDesc, title);
  strcpy(wld->wDesc,  desc);
  if (!*wld->wSDesc)
    sprintf(wld->wSDesc, "Room#%ld", virtual);
  if (!*wld->wDesc)
    sprintf(wld->wDesc, "Description for Room#%ld", virtual);

  sprintf(wld->wFlag, "0");
  sprintf(wld->wType, "1");
  wld->wArea = -99; /* something easy to search and replace on */
  
  sprintf(buf, "%ld %s", virtual, title);
  SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)((LPCSTR)buf));
    
  return wld;
}

WLD *WldCreateCopy(long virtual, WLD *copy) {
  WLD *wld = NULL;

  wld = WldAlloc();
  if (!wld){
    MessageBox(NULL, "WldCreateCopy failure!! out of memory", "Error", MB_OK);
    return NULL;
  }
  wld->wVirtual = virtual;
  wld->wArea = copy->wArea;
  strcpy(wld->wFlag, copy->wFlag);
  strcpy(wld->wType, copy->wType);
  strcpy(wld->wSDesc, copy->wSDesc);
  strcpy(wld->wDesc, copy->wDesc);
}

WLD *WldFind(long virtual) {
  long i;
  
  for (i=0; i<wldMax; i++) {
    if (wldList[i]->wVirtual == virtual)
      return wldList[i];
  }
  //MessageBox(NULL, "AGH", "WldFind: Fall Through to NULL", MB_OK);
  return NULL;
}

/* Update Selection highlight of the listpad to to WLD entry */
void WldSelect(WLD *wld) {
  char buf[256];

  if (wld) {
    sprintf(buf, "%ld ", wld->wVirtual);
    SendMessage(hList, LB_SELECTSTRING, (WPARAM)-1, (LPARAM)((LPCSTR)buf));
  } else {
    SendMessage(hList, LB_SETCURSEL, (WPARAM)-1, 0);
  }
}

void WldFree(long virtual) {  
  long    i;
  long    e;
  ATTACH *attach;
  
  for (i=0; i<wldMax; i++) {
    /* Find the virtual in the list and turf it */
    if (wldList[i]->wVirtual == virtual) {
      for (attach=wldList[i]->wAttach; attach; attach=attach->aNext)
        attach->aChar = 0;
      free(wldList[i]);
      wldMax--;
      wldList[i] = wldList[wldMax];
    }
    /* Turf Exits leading to this Virtual */
    for (e=0; e<EDIR_MAX; e++)
      if (wldList[i]->wEDir[e].eVirtual == virtual)
        memset(&wldList[i]->wEDir[e], 0, sizeof(&wldList[i]->wEDir[e]));
  }
}

void WldFreeAll(void) { 
  long i;
  long a;
  
  for (a=0; a<ATTACH_MAX; a++)
    attachList[a].aChar = 0;
  
  for (i=0; i<wldMax; i++) {
    if (wldList[i])
      free(wldList[i]);
  }
  wldMax = 0;
  
  /* turf everything in hList */
  SendMessage(hList, LB_RESETCONTENT, 0, 0);
}

int WldStrRead(char *str, FILE *file, unsigned int max) {
  char    buf[2];
  char    line[256];
  int     readOK = TRUE;
  
  *str ='\0';
  /* Note: this only ever reads 1 character */
  fgets(buf, sizeof(buf), file);
  while (!feof(file) && buf[0]!='~') {
    switch(buf[0]) {
    case '\r':
      break;
    case '\n':
      if (strlen(str)+3 < max)
        strcat(str, "\r\n");
      else
        readOK = FALSE;
      break;
    default:
      if (strlen(str)+2 < max)
        strcat(str, buf);
      else
        readOK = FALSE;
    }
    
    fgets(buf, sizeof(buf), file);
  }
  /* clear out the line feed etc after the ~ */
  fgets(line, sizeof(line), file);
  
  return readOK;
}

void WldOpen(char *filename) {
  FILE    *file;
  long    i;
  char    wldName[256];
  char    buf[256];
  long    virtual;
  char    title[256];
  char    desc[4096];
  WLD     *wld;
  long    dir;
  
  /* turf what came before */
  WldFreeAll();
  nNextWld = 0;
  
  strcpy(wldName, filename);
  for(i=0; wldName[i] && wldName[i]!='.'; i++);
  if (wldName[i]=='.')
    strcpy(wldName+i, ".wld");
  else
    strcat(wldName, ".wld");
  file = fopen(wldName, "r");
  fgets(buf, sizeof(buf), file);
  while (!feof(file) && buf[0]!='$') {
    /* Read in a Room */
    sscanf(buf, "#%ld\n", &virtual);
    memset(title, 0, sizeof(title));
    memset(desc, 0, sizeof(desc));
    WldStrRead(title, file, sizeof(title));
    WldStrRead(desc, file, sizeof(desc));
    if (strlen(desc)>0 && desc[strlen(desc)-1]=='\n')
      desc[strlen(desc)-1] = '\0';
    if (strlen(desc)>0 && desc[strlen(desc)-1]=='\r')
      desc[strlen(desc)-1] = '\0';
    wld = WldCreate(virtual, title, desc);
    if (virtual>=nNextWld)
      nNextWld = virtual + 1;

    /* read  "0 8 1" */
    fgets(buf, sizeof(buf), file);
    sscanf(buf, "%ld %s %s", &wld->wArea, wld->wFlag, wld->wType);
    
    /* read in exits */
    fgets(buf, sizeof(buf), file);
    
    while (buf[0]!='S') {
      if (buf[0]=='D') {
        buf[2] = 0;
        dir = atoi(buf+1);
        WldStrRead(wld->wEDir[dir].eKey, file, sizeof(wld->wEDir[dir].eKey)); /*  keyword */
        WldStrRead(wld->wEDir[dir].eDesc, file, sizeof(wld->wEDir[dir].eDesc));  /*  desc */
        fgets(buf, sizeof(buf), file);
        sscanf(buf, "%s %ld %ld", &wld->wEDir[dir].eFlag, &wld->wEDir[dir].eKeyNum, &wld->wEDir[dir].eVirtual);
      } else if (buf[0]=='E' || buf[0]=='P') {
        ATTACH *attach = NULL;
        ATTACH *prev;
        int     a;
      
        for (a=0; a<ATTACH_MAX; a++) {
          if (attachList[a].aChar == 0) {
            attach = &attachList[a];
            break;
          }
        }
        if (!attach) {
          MessageBox(NULL, "WldOpen: Create Attachment failure!! out of memory", "Error", MB_OK);
          break;
        }
        memset(attach, 0, sizeof(ATTACH));
        attach->aChar = buf[0];
        WldStrRead(attach->aKey, file, sizeof(attach->aKey));
        WldStrRead(attach->aDesc, file, sizeof(attach->aDesc));
        if (wld->wAttach) {
          prev = wld->wAttach;
          while (prev->aNext) prev = prev->aNext;
          prev->aNext = attach;
        } else {
          wld->wAttach = attach;
        }
      }
      fgets(buf, sizeof(buf), file);
    }
    
    fgets(buf, sizeof(buf), file);
  }

  hActive = NULL;
  wActive = NULL;
  fclose(file);
}

void WldSave(char *filename) {
  FILE    *file;
  long    i;
  long    j;
  size_t  x;
  char    wldName[256];
  ATTACH *attach;
  
  strcpy(wldName, filename);
  for(i=0; wldName[i] && wldName[i]!='.'; i++);
  if (wldName[i]=='.')
    strcpy(wldName+i, ".wld");
  else
    strcat(wldName, ".wld");
  file = fopen(wldName, "wb");
  for (i=0; i<wldMax; i++) {
    /* write out a Room */
    fprintf(file, "#%ld\n", wldList[i]->wVirtual);
    fprintf(file, "%s~\n", wldList[i]->wSDesc);

    for(x=0;wldList[i]->wDesc[x];x++){
      if(wldList[i]->wDesc[x]!='\r') 
        fprintf(file, "%c", wldList[i]->wDesc[x]);
    }
    fprintf(file, "\n~\n");
    
    if (!*wldList[i]->wFlag) strcpy(wldList[i]->wFlag, "0");
    if (!*wldList[i]->wType) strcpy(wldList[i]->wType, "1");
    fprintf(file, "%ld %s %s\n", wldList[i]->wArea, wldList[i]->wFlag, wldList[i]->wType);
    /* write out exits */
    for (j=0; j<EDIR_MAX; j++) {
      if (wldList[i]->wEDir[j].eVirtual) {
        if (!*wldList[i]->wEDir[j].eFlag) strcpy(wldList[i]->wEDir[j].eFlag, "0");
        fprintf(file, 
                "D%ld\n%s~\n%s~\n%s %ld %ld\n", 
                j, 
                wldList[i]->wEDir[j].eKey,
                wldList[i]->wEDir[j].eDesc,
                wldList[i]->wEDir[j].eFlag,
                wldList[i]->wEDir[j].eKeyNum,
                wldList[i]->wEDir[j].eVirtual);
      }
    }
    attach = wldList[i]->wAttach;
    while (attach) {
      fprintf(file, 
              "%c\n%s~\n%s~\n", 
              attach->aChar,
              attach->aKey,
              attach->aDesc);
      attach = attach->aNext;
    }
    fprintf(file, "S\n");
  }
  fprintf(file, "$~\n#9999");
  fclose(file);
}

long WldCount(void) {
  return wldMax;
}