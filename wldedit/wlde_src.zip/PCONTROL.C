#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pcontrol.h"

/*********************************************************************************** 
 Go into PeekMessageLoop to give other things a chance to run
************************************************************************************/
int PeekMessageLoop(void) {
  MSG   msg;

  while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
    if (msg.message == WM_QUIT) {
      /* put quit message back */
      PostQuitMessage(0);
      return FALSE; 
    }
    TranslateMessage(&msg);
    DispatchMessage(&msg);
  }
  return TRUE;
}
/*********************************************************************************** 
 Go into peek-message loop to wait until specified window title is no longer found
************************************************************************************/
int WaitTillFinished(char *title) {
  while (FindWindow(NULL, title) != NULL)
    if (!PeekMessageLoop()) return FALSE;
  return TRUE;
}
                                               
/*********************************************************************************** 
 Go into peek-message loop to wait until specified instance title is no longer found
************************************************************************************/
int WaitTillInstFinished(HANDLE theInst) {
  int count;
    
  count = GetModuleUsage(theInst);
  if (count>0) {
    while(GetModuleUsage(theInst)>=count)
      if (!PeekMessageLoop()) return FALSE;
  }
  return TRUE;
}

/*********************************************************************************** 
 Delay so other apps can run
************************************************************************************/
int Delay(int seconds) {
  DWORD startCount;
  DWORD endCount;
  DWORD currentCount;

  startCount = GetTickCount();
  endCount = startCount + seconds*1000;
  do {
    if (!PeekMessageLoop()) return 0; /* quit */
    currentCount = GetTickCount();
  } while (currentCount >= startCount && currentCount <= endCount);

  return 1;
}
