#include <windows.h>            	/* required for all Windows applications */
#include <commdlg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 					/* technically I should use LPSTR's etc */
#include "wld.h"
#include "wldedit.h"            	/* specific to this program          */ 
#include "stddesc.h"

long stdDescMax = 0;
STDDESC *stdDescList[STDDESC_MAX];

void StdDescInit(void) {
	stdDescMax = 0;
}


STDDESC *StdDescCreate(HWND hWnd, char *title, char *desc) {
	int					 	i;
	HMENU 				hMenu;
	HMENU 				hPopup;
	STDDESC 			*stdDesc;

	hMenu = GetMenu(hWnd);
	hPopup = GetSubMenu(hMenu, 3); /* report menu is in the 3rd position, (starting at 0) */

	if (stdDescMax>=STDDESC_MAX-1) {
		MessageBox(NULL, "StdDescCreate out of entries", "Error", MB_OK);
		return NULL;
	}
	stdDesc = malloc(sizeof(STDDESC));
	if (!stdDesc) {
		MessageBox(NULL, "StdDescCreate malloc failure", "Error", MB_OK);
		return NULL;
	}
	strcpy(stdDesc->sTitle, title);
	strcpy(stdDesc->sDesc,  desc);
	stdDescList[stdDescMax] = stdDesc;
	i = (int)stdDescMax;
	if (!InsertMenu(hPopup, 3+i, MF_BYPOSITION|MF_STRING, IDM_STDDESC+i, stdDescList[i]->sTitle))
		MessageBox(NULL, "Unable to insert Menu Item", stdDescList[i]->sTitle, MB_OK);
	stdDescMax++;
	return stdDesc;
}

void StdDescDelete(HWND hWnd, int index) {
	HMENU 				hMenu;
	HMENU 				hPopup;
	int						i;

	hMenu = GetMenu(hWnd);
	hPopup = GetSubMenu(hMenu, 3); /* report menu is in the 3rd position, (starting at 0) */

	/* turf old list of entries */
	for (i=0; i<stdDescMax; i++) {
		RemoveMenu(hPopup, IDM_STDDESC+i, MF_BYCOMMAND);
	}
	
	free(stdDescList[index]);
	if (index!=stdDescMax-1) {
		stdDescList[index] = stdDescList[stdDescMax-1];
	}
	stdDescMax--;

	/* add list of stdDesc's back to menu */
	for (i=0; i<stdDescMax; i++) {
		if (!InsertMenu(hPopup, 3+i, MF_BYPOSITION|MF_STRING, IDM_STDDESC+i, stdDescList[i]->sTitle))
			MessageBox(NULL, "Unable to insert Menu Item", stdDescList[i]->sTitle, MB_OK);
	}
}

STDDESC *StdDescFind(long index) {
	return stdDescList[index];
}

void StdDescFreeAll(void) {
	long i;
	
	for (i=0; i<stdDescMax; i++) {
		free (stdDescList[i]);
	}
}

void StdDescSave(void) {
	long 		i,j;
	FILE 		*file;
	
	file = fopen("stddesc.tab", "wt");
	if (!file) {
		MessageBox(NULL, "StdDescSave: Unable to open file", "File Error", MB_OK);
		return;
	}
	for (i=0; i<stdDescMax; i++) {
		fprintf(file, "%s\n", stdDescList[i]->sTitle);
		for (j=0; stdDescList[i]->sDesc[j]; j++) {
			if (stdDescList[i]->sDesc[j] != '\r')
				fprintf(file, "%c", stdDescList[i]->sDesc[j]);
		}
		fprintf(file, "~\n");
	}
	fprintf(file, "$\n");
	fclose(file);
}

/* add the list of StdDesc's to the Combo Box */
void StdDescAddItems(HWND hDialog, int controlID) {
	long 		i;
	DWORD dwIndex;
	
	for (i=0; i<stdDescMax; i++) {
		dwIndex = SendDlgItemMessage(
			hDialog, 
			controlID,
   		CB_ADDSTRING, 
   		0, 
   		(LPARAM) ((LPSTR) stdDescList[i]->sTitle));
	}
	/* select the first item */
	SendDlgItemMessage(
			hDialog, 
			controlID,
   		CB_SETCURSEL, 
   		0, 
   		0L);
}

void StdDescRead(HWND hWnd) {
	FILE 					*file;
	char  				buf[2];
	char  				title[128];
	char  				desc[512];
	
	/* Generate report menu based on stddesc.tab file */
	file = fopen("stddesc.tab", "rt");
	if (file) {
		fgets(title, sizeof(title), file);
		while (!feof(file) && title[0]!='$') {
			/* Remove trailing returns from title */
			while (title[strlen(title)-1] == '\n') 
				title[strlen(title)-1] = '\0';

			desc[0] = '\0';
			fgets(buf, sizeof(buf), file); /* since buf is only 2 bytes, we get one character at a time */
			while (!feof(file) && buf[0]!='~') {
				if (buf[0]!='\r') { /* dont want these */
					if (buf[0]=='\n') /* xlation mode so there should be no \r's */
						strcat(desc, "\r");
					strcat(desc, buf); /* in memory we want \r\n */
				}
				fgets(buf, sizeof(buf), file);
			}
			if (!StdDescCreate(hWnd, title, desc)) {
				MessageBox(hWnd, "WARNING! - Extra Ignored", "Memory exceeded", MB_ICONSTOP);
				break;
			}
			
			fgets(title, sizeof(title), file); /* clear out return after ~ */
			fgets(title, sizeof(title), file); /* read next title */
		}
		fclose(file); 
	}
}

